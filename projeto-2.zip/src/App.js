import Footer from './componentes/Footer';
import Header from './componentes/Header';
import Content from './componentes/Content';




function App() {
  return (
    <>
      <Header />
      <Content />
      <Footer />
    </>
  );
}
 
export default App;
