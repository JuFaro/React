import {Switch, Route} from 'react-router-dom';
import Home from '../paginas/Home';
import NotFound from '../paginas/NotFound';
import Produtos from '../paginas/Produtos';
import SobreEmpresa from '../paginas/SobreEmpresa';

function Content(){
    return(
            <>
            <section className='content'>
                <Switch>
                    <Route exact path='/' component={Home}/>
                    <Route exact path='/Produtos' component={Produtos}/>
                    <Route exact path='/SobreEmpresa' component={SobreEmpresa}/>
                    <Route component={NotFound}/>
                </Switch>
            </section>
            </>
    )
}

export default Content;