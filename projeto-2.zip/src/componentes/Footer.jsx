function Footer(){
    return(
        <>
        <h1>Todos os Direitos Reservados</h1>
      
        </>
    )
}

export default Footer;