function SobreEmpresa(){
    return(
            <>
            <h1>Aqui é sobre Empresa</h1>
            </>
    )
}

export default SobreEmpresa;