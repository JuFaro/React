function Home(){
    return(
            <>
            <h1>Aqui é a home</h1>
            </>
    )
}

export default Home;