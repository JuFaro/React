function Produtos(){
    return(
            <>
            <h1>Aqui são os Produtos</h1>
            </>
    )
}

export default Produtos;