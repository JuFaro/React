import React from 'react';

function Assina(){
    return(
        <section className="assina">
        <h3>Novidades</h3>        
            <p>Asssine nosso canal para receber ofertas e novidades do hotel</p>        
        <hr/>       
            <form id="form1" method="post" name="form1"       
            onsubmit="return valida(this)">        
                <input type="email" placeholder="Email" id="email"/>            
                <button>Cadastrar</button>        
            </form>    
    </section>
    )
}

export default Assina;