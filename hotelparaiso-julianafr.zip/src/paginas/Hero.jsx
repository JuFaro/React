import React from 'react';

function Hero(){
    return(
            <>
               <section className="hero">
            <h1>Conheça esse paraiso chamado Sobral</h1>
            <h3>"Aconchego, conforto, simpatia e muito alto astral"</h3>
            <a href="" className="btn">Saiba mais</a>
        </section>
            </>
    )
}

export default Hero;