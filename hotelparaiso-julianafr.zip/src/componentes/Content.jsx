import {Switch, Route} from 'react-router-dom';
import Hotel from '../paginas/Hotel';
import Hero from '../paginas/Hero';
import Info from '../paginas/Info';
import Assina from '../paginas/Assina';
import NotFound from '../paginas/NotFound';

function Content(){
    return(
            <>
            <section className='content'>
                <div className='ajuste'>
                <Switch>
                    <Route exact path='/' component={Hero}/>
                    <Route exact path='/Hotel' component={Hotel}/>
                    <Route exact path='/Info' component={Info}/>
                    <Route exact path='/Assina' component={Assina}/>
                    <Route component={NotFound}/>
                </Switch>
                </div>

            </section>
            </>
    )
}

export default Content;