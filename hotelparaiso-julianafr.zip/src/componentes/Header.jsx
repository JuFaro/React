import React from 'react';
import {Link} from 'react-router-dom';
import Logo from '../img/logo.jpg'

function Header(){
    return(
        <header>
            <Link to='/'><img src={Logo} alt="Hotel Paraíso" /></Link>
        <nav>
            <ul>
                <li><Link to='/'>Hero</Link></li>
                <li><Link to='/Hotel'>Hotel</Link></li>
                <li><Link to='/Info'>Info</Link></li>
                <li><Link to='/Assina'>Assina</Link></li>
            </ul>
        </nav>
    </header>

    )
}

export default Header;