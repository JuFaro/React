import React from 'react';
import Content from './componentes/Content';
import Footer from './componentes/Footer';
import Header from './componentes/Header';



function App() {
  return (
    <>
      <Header />
      <Content />
      <Footer />
    </>
  );
}

export default App;

